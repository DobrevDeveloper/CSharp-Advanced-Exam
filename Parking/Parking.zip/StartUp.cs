﻿using System;

namespace Parking
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
        }
    }
}